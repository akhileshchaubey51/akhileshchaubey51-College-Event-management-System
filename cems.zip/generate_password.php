<?php
// Replace 'yourpassword' with the actual password you want to hash
echo password_hash('yourpassword', PASSWORD_DEFAULT);
?>
