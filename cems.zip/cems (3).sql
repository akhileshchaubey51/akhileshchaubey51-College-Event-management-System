-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2025 at 07:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `event_id`, `booking_date`, `status`) VALUES
(1, 2, 1, '2025-04-08 16:34:53', ''),
(2, 2, 2, '2025-04-08 16:34:53', '');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Technical', 'Technical events and competitions', '2025-04-08 16:28:43'),
(2, 'Cultural', 'Cultural and fest activities', '2025-04-08 16:28:43'),
(3, 'Sport', 'Sports events such as cricket, football, and athletics competitions.', '2025-04-09 16:40:18');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `message`, `submitted_at`) VALUES
(4, 'akhilesh Chaubey', 'akhileshchaubey.230411222@gehu.ac.in', 'kjdsghkjghkjdfg', '2025-05-02 16:37:24');

-- --------------------------------------------------------

--
-- Table structure for table `cultural_events`
--

CREATE TABLE `cultural_events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `event_date` date NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `event_name` varchar(100) DEFAULT NULL,
  `event_type` varchar(50) DEFAULT NULL,
  `is_paid` tinyint(1) DEFAULT 0,
  `amount` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cultural_events`
--

INSERT INTO `cultural_events` (`id`, `title`, `category`, `event_date`, `image_path`, `event_name`, `event_type`, `is_paid`, `amount`) VALUES
(1, '', 'Holi', '2026-03-15', 'uploads/holi.jpeg', 'Holi', 'Cultural', 0, 0),
(2, '', 'Diwali\r\n', '2025-11-09', 'uploads/diwali.jpeg', 'diwali', 'Cultural', 0, 0),
(3, '', 'Freshers', '2025-08-08', 'uploads/Freshers(Dance).jpeg', 'Freshers(Dance)', 'Cultural', 0, 0),
(4, '', 'Freshers', '2025-08-08', 'uploads/Freshers(Singing).jpeg', 'Freshers(Singing)', 'Cultural', 0, 0),
(5, '', 'Freshers', '2025-08-08', 'uploads/Freshers(Act-play).jpeg', 'Freshers(Act-play)', 'Cultural', 0, 0),
(7, '', 'Diwali', '2025-11-01', 'uploads/Diwali(Dance).jpeg', 'Diwali(Dance)', 'Cultural', 0, 0),
(8, '', 'Diwali', '2025-11-09', 'uploads/Diwali(Singing).jpeg', 'Diwali(Singing)', 'Cultural', 0, 0),
(9, '', 'Diwali', '2025-11-09', 'uploads/Diwali(Act-play).jpeg', 'Diwali(Act-play)', 'Cultural', 0, 0),
(10, '', 'Holi', '2025-03-09', 'uploads/Holi(Dance).jpeg', 'Holi(Dance)', 'Cultural', 0, 0),
(11, '', 'Holi', '2025-03-09', 'uploads/Holi(Singing).jpeg', 'Holi(Singing)', 'Cultural', 0, 0),
(12, '', 'Holi', '2025-03-09', 'uploads/Holi(Act-play).jpeg', 'Holi(Act-play)', 'Cultural', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `event_time` time DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `category_id`, `title`, `description`, `event_date`, `event_time`, `venue`, `image`, `price`, `created_at`, `category`) VALUES
(1, 1, 'Coding Hackathon', '24-hour coding competition', '2025-04-15', '09:00:00', 'Auditorium', 'uploads/hackathon.jpg', 100.00, '2025-04-08 16:33:02', 'tech event'),
(2, 2, 'Cultural Night', 'A night full of cultural programs', '2025-04-20', '18:00:00', 'Open Ground', 'uploads/drama-night.jpg', 50.00, '2025-04-08 16:33:02', 'tech event'),
(3, 1, 'Hackathon 2025', '24-hour coding challenge with exciting prizes.', '2025-05-10', '09:00:00', 'Auditorium Hall A', 'uploads/hackathon.jpg', 0.00, '2025-04-09 16:47:48', 'tech event'),
(4, 1, 'AI Workshop', 'Hands-on session on AI & ML models.', '2025-05-12', '11:00:00', 'Lab 2', 'uploads/ai-workshop.jpg', 100.00, '2025-04-09 16:47:48', 'tech event'),
(5, 1, 'Web Dev Bootcamp', 'Learn to build websites in 2 days.', '2025-05-18', '10:00:00', 'Computer Lab 1', 'uploads/web-bootcamp.jpg', 50.00, '2025-04-09 16:47:48', 'tech event'),
(6, 1, 'Cyber Security Talk', 'Experts talk about cyber threats.', '2025-05-22', '14:00:00', 'Seminar Hall', 'uploads/cyber-security.jpg', 0.00, '2025-04-09 16:47:48', 'tech event'),
(7, 2, 'Cultural Fest', 'A grand celebration of culture.', '2025-05-15', '18:00:00', 'Main Stage', 'uploads/cultural.jpg', 50.00, '2025-04-09 16:47:48', 'Cultural event'),
(8, 2, 'Drama Night', 'Drama performance by college students.', '2025-05-19', '19:00:00', 'Open Air Theatre', 'uploads/drama-night.jpg', 30.00, '2025-04-09 16:47:48', 'Cultural event'),
(9, 2, 'Music Concert', 'Live music concert with local bands.', '2025-05-21', '20:00:00', 'Auditorium', 'uploads/music-concert.jpg', 100.00, '2025-04-09 16:47:48', 'Cultural event'),
(10, 2, 'Art Exhibition', 'Exhibition of student artworks.', '2025-05-25', '12:00:00', 'Exhibition Hall', 'uploads/art-exhibition.jpg', 20.00, '2025-04-09 16:47:48', 'Cultural event'),
(11, 3, 'Annual Sports Meet', 'Track and field events.', '2025-05-20', '08:00:00', 'Sports Ground', 'uploads/sports.jpg', 0.00, '2025-04-09 16:47:48', 'sport event'),
(12, 3, 'Football Tournament', 'Inter-college football tournament.', '2025-05-23', '09:00:00', 'Football Ground', 'uploads/football.jpg', 0.00, '2025-04-09 16:47:48', 'sport event'),
(13, 3, 'Badminton Championship', 'Singles and doubles matches.', '2025-05-24', '10:00:00', 'Indoor Stadium', 'uploads/badminton.jpg', 0.00, '2025-04-09 16:47:48', 'sport event'),
(14, 3, 'Cricket League', 'Inter-department cricket league.', '2025-05-28', '08:30:00', 'Cricket Ground', 'uploads/cricket.jpg', 0.00, '2025-04-09 16:47:48', 'sport event');

-- --------------------------------------------------------

--
-- Table structure for table `event_registrations`
--

CREATE TABLE `event_registrations` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `event_type` enum('Tech','Cultural','Sport') NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `event_name` varchar(255) NOT NULL,
  `payment_screenshot` varchar(255) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT 'not_required',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_registrations`
--

INSERT INTO `event_registrations` (`id`, `event_id`, `event_type`, `name`, `email`, `phone`, `registered_at`, `event_name`, `payment_screenshot`, `payment_status`, `amount`) VALUES
(26, 1, 'Tech', 'akhilesh Chaubey', 'akhileshchaubey.230411222@gehu.ac.in', '9759790023', '2025-05-02 16:39:44', 'Takken', 'payment_screenshots/1746203997_1746118849_coding.jpg', 'Paid', 0.00),
(27, 2, 'Cultural', 'akhilesh Chaubey', 'akhileshchaubey.230411222@gehu.ac.in', '9759790023', '2025-05-02 16:42:46', 'diwali', NULL, 'not_required', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `comments` text DEFAULT NULL,
  `feedback_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `event_id`, `rating`, `comments`, `feedback_date`) VALUES
(1, 2, 1, 5, 'Amazing hackathon event!', '2025-04-08 16:35:38'),
(2, 2, 2, 4, 'Great cultural night!', '2025-04-08 16:35:38'),
(17, 3, NULL, NULL, 'Akhilesh is the best in the world', '2025-04-25 17:56:14');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `event_id`, `image`, `caption`, `uploaded_at`) VALUES
(1, 1, 'hackathon1.jpg', NULL, '2025-04-08 16:36:19'),
(2, 2, 'culturalnight1.jpg', NULL, '2025-04-08 16:36:19');

-- --------------------------------------------------------

--
-- Table structure for table `payment_submissions`
--

CREATE TABLE `payment_submissions` (
  `id` int(11) NOT NULL,
  `registration_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `event_type` enum('Tech','Cultural','Sport') NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `event_name` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sponsors`
--

CREATE TABLE `sponsors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sponsors`
--

INSERT INTO `sponsors` (`id`, `name`, `logo`, `description`, `contact_email`, `website`, `created_at`) VALUES
(1, 'Tech Corp', 'techcorp.png', NULL, NULL, 'https://techcorp.com', '2025-04-08 16:29:10'),
(2, 'Culture Inc.', 'cultureinc.png', NULL, NULL, 'https://cultureinc.com', '2025-04-08 16:29:10');

-- --------------------------------------------------------

--
-- Table structure for table `sport_events`
--

CREATE TABLE `sport_events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `is_paid` tinyint(1) DEFAULT 0,
  `amount` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sport_events`
--

INSERT INTO `sport_events` (`id`, `title`, `category`, `event_date`, `image_path`, `event_name`, `event_type`, `is_paid`, `amount`) VALUES
(1, '', ' On 9-July\r\nRs100/Team\r\n\r\n', '2025-07-30', 'uploads/cricket.jpg', 'Cricket', 'Sports', 1, 100),
(2, '', 'On 9-July\r\nRs100/Team\r\n\r\n', '2025-07-09', 'uploads/Basketball.webp', 'Basketball', 'Sports', 1, 100),
(3, '', 'On 12-July\r\nRs100/Team\r\n\r\n', '2025-07-24', 'uploads/Volleyball.jpg', 'Volleyball', 'Sports', 1, 100),
(4, '', 'On 12-July\r\nRs100/Team\r\n\r\n', '2025-07-20', 'uploads/Tressure Hunt.jpg', 'Tressure Hunt', 'Sports', 1, 100),
(5, '', 'On 15-July\r\nRs100/Team\r\n\r\n', '2025-07-15', 'uploads/riddle.jpg', 'riddle', 'Sports', 1, 100),
(6, '', 'On 9-July\r\nRs100/Team\r\n\r\n', '2025-07-19', 'uploads/badminton.jpg', 'badminton', 'Sports', 1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `tech_events`
--

CREATE TABLE `tech_events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `event_date` date NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `is_paid` tinyint(1) DEFAULT 0,
  `amount` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tech_events`
--

INSERT INTO `tech_events` (`id`, `title`, `category`, `event_date`, `image_path`, `event_name`, `event_type`, `is_paid`, `amount`) VALUES
(1, 'Players: 1/1\r\nVenue: Lab\r\nEntry Fee: Rs40\r\nTiming: 9-10am\r\n\r\n', 'Takken', '2025-05-25', 'uploads/takken.png', 'Takken', 'Tech', 1, 40),
(2, 'Players: 4/4\r\nVenue: Lab\r\nEntry Fee: Rs40\r\nTiming: 9-10am\r\n\r\n', 'BGMI', '2025-05-25', 'uploads/BGMI.png', 'BGMI', 'Tech', 1, 40),
(3, 'Players: 4/4\r\nVenue: Lab\r\nEntry Fee: Rs40\r\nTiming: 9-10am\r\n\r\n', 'Free fire', '2025-05-25', 'uploads/freefire.jpg', 'Free Fire', 'Tech', 1, 40),
(4, 'Players: 4/4\r\nVenue: Lab\r\nEntry Fee: Rs40\r\nTiming: 9-10am\r\n\r\n', 'Coding', '2025-05-25', 'uploads/coding.jpg', 'Coding', 'Tech', 1, 40),
(5, 'Players: 4/4\r\nVenue: Lab\r\nEntry Fee: Rs40\r\nTiming: 24x7\r\n\r\n', 'Hackathon', '2025-05-25', 'uploads/Hackathon.jpg', 'Hackathon', 'Tech', 1, 40);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','admin') DEFAULT 'student',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_image` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `profile_image`, `user_id`) VALUES
(1, 'Akhilesh Chaubey', 'akhilesh@gehu.ac.in', '$2y$10$xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'admin', '2025-04-08 16:28:21', NULL, 0),
(2, 'John Doe', 'john@gehu.ac.in', 'Johngehu@123', 'student', '2025-04-08 16:28:21', NULL, 0),
(3, 'Akhilesh Chaubey', 'akhileshchaubey.230411222@gehu.ac.in', '$2y$10$uEYVJECCR2DHvsKNXo65Z.ma3MLDRSRo4YHsJWR7yKugW9z2mRqUe', 'admin', '2025-04-08 16:53:26', '1745603922_IMG-20241113-WA0003.jpg', 0),
(4, '', 'pankajairi.22446688@gehu.ac.in', '$2y$10$GkbWtONlz98R336biOH4rOgU.CZPj1gO/fARdW4RixZsjBn4qpEay', 'student', '2025-04-18 06:14:38', 'image.webp', 0),
(6, 'manoj mehta', 'manojmehta22446688@gehu.ac.in', '$2y$10$n/kBvK.D2wNw6efFeyhTGu5vuXpTVFUqfcZHBdHKfCIUfmZ6Yz7QW', 'student', '2025-04-18 06:21:35', 'image.webp', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cultural_events`
--
ALTER TABLE `cultural_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `payment_submissions`
--
ALTER TABLE `payment_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registration_id` (`registration_id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`event_id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sponsors`
--
ALTER TABLE `sponsors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sport_events`
--
ALTER TABLE `sport_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tech_events`
--
ALTER TABLE `tech_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cultural_events`
--
ALTER TABLE `cultural_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `event_registrations`
--
ALTER TABLE `event_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_submissions`
--
ALTER TABLE `payment_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sponsors`
--
ALTER TABLE `sponsors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sport_events`
--
ALTER TABLE `sport_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tech_events`
--
ALTER TABLE `tech_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);

--
-- Constraints for table `payment_submissions`
--
ALTER TABLE `payment_submissions`
  ADD CONSTRAINT `payment_submissions_ibfk_1` FOREIGN KEY (`registration_id`) REFERENCES `event_registrations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `tech_events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `cultural_events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `registrations_ibfk_3` FOREIGN KEY (`event_id`) REFERENCES `sport_events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `registrations_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
